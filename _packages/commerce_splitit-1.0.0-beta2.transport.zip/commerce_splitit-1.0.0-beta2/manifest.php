<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Splitit Payment Gateway Integration for Commerce on the MODX CMS.
==
Development by Murray Wood at Digital Penguin.
Thanks to Julien Studer at nopixel for sponsoring the development of this module.

Requirements
-
Commerce_Splitit requires at least MODX 2.6.5 and PHP 7.1 or higher. Commerce by modmore should be at least version 1.1.4. You also need to have a Splitit merchant account which provides a username, a password, a sandbox API key and a production API key.

Installation
-
Install via the MODX package manager. The package name is Commerce_Splitit.

Setup
-
Once installed, navigate to Commerce in the MODX manager. Select the `Configuration` tab and then click on `Modules`. Find Commerce_Splitit in the module list and click on it to make a window pop up where you can enable the module for `Test Mode`, `Live Mode`, or both. Note that while Commerce is set to test mode, Commerce_Splitit will automatically use the sandbox API. Setting Commerce to Live Mode will use Splitit\'s production API.

Now the module is enabled, you can click on the `Payment Methods` tab on the left. Then click `Add a Payment Method`. Select Splitit from the Gateway dropdown box and then give it a name e.g. Splitit.
Next, click on the availability tab and enable it for test or live modes and then click save.

After saving, you\'ll see a Splitit tab appears at the top of the window. Here you can enter your Splitit API credentials: Username, password, sandbox API key and production API key. If for some reason you only have the one API key, enter it for both.

*Congratulations!* Splitit should now appear as a payment method a customer can use during checkout.

Form Styling
-
Splitit provides its own CSS for the payment widget and this is enabled by default. If you would like to completely restyle it from scratch, you can disable the system setting under the Commerce_Splitit namespace `use_default_css`.',
    'changelog' => 'Splitit for Commerce 1.0.0-beta2
---------------------------------
Released on 03-11-2020
- Added workaround for if ObfuscateEmail plugin is active. Splitit can\'t handle escaped email addresses.

Released on 16-10-2020
- First beta release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '89482ee886e02e2df36398c9207730c4',
      'native_key' => 'commerce_splitit',
      'filename' => 'modNamespace/1d00656f7db574b72a63c8033c2c9956.vehicle',
      'namespace' => 'commerce_splitit',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '905620ff5d2fe28210a045c025a206c2',
      'native_key' => '905620ff5d2fe28210a045c025a206c2',
      'filename' => 'xPDOFileVehicle/e5fb21559d9732626e36fd90d6bb1492.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e5cb68bd26ea3383446845e90b7d52',
      'native_key' => 'commerce_splitit.use_default_css',
      'filename' => 'modSystemSetting/2ed514d12ab5003e2f261cd69ac498e4.vehicle',
      'namespace' => 'commerce_splitit',
    ),
  ),
);