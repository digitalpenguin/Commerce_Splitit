<?php

$_lang['commerce_splitit'] = 'Commerce_Splitit';
$_lang['commerce_splitit.description'] = 'Commerce_Splitit integrates Splitit into Commerce for MODX. Splitit allows a customer to break up a payment into multiple parts on a schedule when at the checkout.';

$_lang['commerce_splitit.gateway'] = 'Splitit';
$_lang['commerce_splitit.payment_verified'] = 'Payment verified';
$_lang['commerce_splitit.payment_not_verified'] = 'Payment not verified';