<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Splitit Payment Gateway Integration for Commerce on the MODX CMS.
==
Development by Murray Wood at Digital Penguin.
Thanks to Julien Studer at nopixel for sponsoring the development of this module.

Requirements
-
Commerce_Splitit requires at least MODX 2.6.5 and PHP 7.1 or higher. Commerce by modmore should be at least version 1.1.4. You also need to have a Splitit merchant account which provides a username, a password, a sandbox API key and a production API key.

Installation
-
Install via the MODX package manager. The package name is Commerce_Splitit.

Setup
-
Once installed, navigate to Commerce in the MODX manager. Select the `Configuration` tab and then click on `Modules`. Find Commerce_Splitit in the module list and click on it to make a window pop up where you can enable the module for `Test Mode`, `Live Mode`, or both. Note that while Commerce is set to test mode, Commerce_Splitit will automatically use the sandbox API. Setting Commerce to Live Mode will use Splitit\'s production API.

Now the module is enabled, you can click on the `Payment Methods` tab on the left. Then click `Add a Payment Method`. Select Splitit from the Gateway dropdown box and then give it a name e.g. Splitit.
Next, click on the availability tab and enable it for test or live modes and then click save.

After saving, you\'ll see a Splitit tab appears at the top of the window. Here you can enter your Splitit API credentials: Username, password, sandbox API key and production API key. If for some reason you only have the one API key, enter it for both.

*Congratulations!* Splitit should now appear as a payment method a customer can use during checkout.

Form Styling
-
Splitit provides its own CSS for the payment widget and this is enabled by default. If you would like to completely restyle it from scratch, you can disable the system setting under the Commerce_Splitit namespace `use_default_css`.

Payment Wizard Configuration
-
*New in version 1.1.0-pl*

Two new system settings are offered to allow you to configure the payment wizard. You can now set the number of installments the customer can pick from,
as well as the percentage of the first installment.

**System Settings**

- commerce_splitit.first_installment_percentage - Value should be an integer or a float. Don\'t include the percentage symbol.
- commerce_splitit.num_of_installments - Value should be a comma-separated list of integers. Example: `2,3,4,5,6`
',
    'changelog' => 'Splitit for Commerce 1.1.0-pl
---------------------------------
Released on 25-11-2020
- Added functionality to set the number of payment installments offered to customers.
- Added functionality to set percentage of first payment amount.
- New system setting: commerce_splitit.first_installment_percentage
- New system setting: commerce_splitit.num_of_installments
- Added new lexicon values

Splitit for Commerce 1.0.0-pl
---------------------------------
Released on 12-11-2020
- Added Splitit prefix to form element ids to ensure no conflicts with other active gateways.
- First pl release.

Splitit for Commerce 1.0.0-beta2
---------------------------------
Released on 03-11-2020
- Added workaround for if ObfuscateEmail plugin is active. Splitit can\'t handle escaped email addresses.

Released on 16-10-2020
- First beta release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ef6d6476d4a26e18ba25378f384f2d26',
      'native_key' => 'commerce_splitit',
      'filename' => 'modNamespace/10becbaf1d9abf40340ba6c8522a5a0c.vehicle',
      'namespace' => 'commerce_splitit',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e200d0d987d276a3744d480965794224',
      'native_key' => 'e200d0d987d276a3744d480965794224',
      'filename' => 'xPDOFileVehicle/ce65f6965fca473630b65cdab8adab62.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67f26ae6a80c8032a1d65792b8222640',
      'native_key' => 'commerce_splitit.use_default_css',
      'filename' => 'modSystemSetting/9ac8d9ed85e8059d2aa53917da034aa3.vehicle',
      'namespace' => 'commerce_splitit',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcd5fffd2d0a1639c2cd427065de64c0',
      'native_key' => 'commerce_splitit.first_installment_percentage',
      'filename' => 'modSystemSetting/244d92280f3ee3bab71c190db79e76dd.vehicle',
      'namespace' => 'commerce_splitit',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00ee26a8ced87d2f3f8b0b49591b1bf6',
      'native_key' => 'commerce_splitit.num_of_installments',
      'filename' => 'modSystemSetting/1829d458754e0d3e74bd651492c55769.vehicle',
      'namespace' => 'commerce_splitit',
    ),
  ),
);