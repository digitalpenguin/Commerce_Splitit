<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '## Splitit Payment Gateway Integration for Commerce on the MODX CMS.

Development by Murray Wood at Digital Penguin.
Thanks to Julien Studer at nopixel for sponsoring the development of this module.

### New API

Splitit has recently completely changed their API and as such, older versions of this module won\'t work anymore. Version 2.0+ is required.

### Regarding Stripe

Splitit has Stripe as an option for the payment processor. Be aware that if you use Stripe through Splitit AND also
accept Stripe payments directly, then two Stripe accounts should be used. If a single account is used, webhook requests
can be triggered by Stripe with the incorrect transaction.

### Requirements

Commerce_Splitit requires at least MODX 2.6.5 and PHP 7.4 or higher. Commerce by modmore should be at least version 1.4. You also need to have a Splitit merchant account which provides a username and a password.

### Installation

Install via the MODX package manager. https://extras.modx.com/package/splititpaymentgatewayforcommerce

### Setup

Once installed, navigate to Commerce in the MODX manager. Select the `Configuration` tab and then click on `Modules`. Find Commerce_Splitit in the module list and click on it to make a window pop up where you can enable the module for `Test Mode`, `Live Mode`, or both. Note that while Commerce is set to test mode, Commerce_Splitit will automatically use the sandbox API. Setting Commerce to Live Mode will use Splitit\'s production API.

Now the module is enabled, you can click on the `Payment Methods` tab on the left. Then click `Add a Payment Method`. Select Splitit from the Gateway dropdown box and then give it a name e.g. Splitit.
Next, click on the availability tab and enable it for test or live modes and then click save.

After saving, you\'ll see a Splitit tab appears at the top of the window. Here you can enter your Splitit API credentials: Username, password, API key and set 3DSecure.

*Congratulations!* Splitit should now appear as a payment method a customer can use during checkout.

### Form Styling

Here\'s an example of the form with default styling:

![Screenshot 2024-01-25 at 15-09-17 Checkout - MODX Revolution](https://github.com/digitalpenguin/Commerce_Splitit/assets/5160368/bc3f4c15-df0c-481a-ad37-dc372dc4eaaa)

Splitit makes a list of CSS class available to style. Default values shown here:
```css
--spt-color-primary: #732c70,
--spt-color-pay-button: #000,
--spt-color-pay-button-text: #fff,
--spt-color-pay-button-disabled: #00000033,
--spt-color-border-focused: #732c70,
--spt-color-border-idle: rgba(203, 203, 203, 0.54),
--spt-color-border-error: #ff0000,
--spt-color-error: #ff0000,
--spt-color-text: #000,
--spt-color-labels: #757575,
--spt-color-main-shade: #ece8ee,
--spt-color-link: rgb(125, 166, 222)
```
In case these change in the future, here is [the link](https://developers.splitit.com/checkout-solutions/hosted-fields/#customization).

### Configuration

**Payment Method Settings**

- `API Username` - Found in the Splitit dashboard under "Splitit Integration Credentials"
- `API Password` - Found in the Splitit dashboard under "Splitit Integration Credentials"
- `Payment Terminal API Key` - Found in the Splitit dashboard under "Gateway Provider Credentials"
- `Use 3DSecure` - Check this to use 3D Secure

![Screenshot 2024-01-25 at 15-10-29 Commerce » Payment Methods MODX Revolution](https://github.com/digitalpenguin/Commerce_Splitit/assets/5160368/1b388da7-a298-49cf-a7ce-c6e05a48ece5)

**System Settings**
- `commerce_splitit.first_installment_percentage` - Value should be an integer or a float. Don\'t include the percentage symbol.
- `commerce_splitit.num_of_installments` - Value should be a comma-separated list of integers. Example: `2,3,4,5,6`
- `commerce_splitit.num_of_installments_default` - Value should be an integer. Sets which payment option is pre-selected when the form loads.
- `commerce_splitit.locale` - Sets the locale for Splitit which will typically affect the language that\'s used. e.g. `en-US` or `fr-FR` etc.

![Screenshot 2024-01-25 at 15-05-39 System Settings MODX Revolution](https://github.com/digitalpenguin/Commerce_Splitit/assets/5160368/390c53e9-1cba-44df-b289-c6e49f27c271)',
    'changelog' => 'Splitit for Commerce 2.1.0-pl
---------------------------------
Released on 25-01-2024

- Add 3D Secure option to payment method options
- Remove defunct use_default_css system setting
- Make first_installment_percentage and num_of_installments settings work properly again
- Add num_of_installments_default setting
- Various minor improvements

Splitit for Commerce 2.0.0-pl
---------------------------------
Released on 19-10-2023

- Huge refactor due to Splitit changing their API to v3. Old versions of this module will no longer work.

Splitit for Commerce 1.1.3-pl
---------------------------------
Released on 08-08-2023

- Refactor response handling due to change in Splitit API
- Update module to use \\modmore\\Commerce\\Dispatcher\\EventDispatcher
- Update requirements to Commerce 1.3 minimum

Splitit for Commerce 1.1.2-pl
---------------------------------
Released on 30-03-2020

- Force price submitted to Splitit to use a \'.\' as decimal place, even if the locale/currency uses something else.

Splitit for Commerce 1.1.1-pl
---------------------------------
Released on 28-11-2020
- Removed Obfuscate email workaround as no longer needed.
- Fixed rounding bug which prevented Splitit form from loading sometimes when using "first_installment_percentage" system setting.

Splitit for Commerce 1.1.0-pl
---------------------------------
Released on 25-11-2020
- Added functionality to set the number of payment installments offered to customers.
- Added functionality to set percentage of first payment amount.
- New system setting: commerce_splitit.first_installment_percentage
- New system setting: commerce_splitit.num_of_installments
- Added new lexicon values

Splitit for Commerce 1.0.0-pl
---------------------------------
Released on 12-11-2020
- Added Splitit prefix to form element ids to ensure no conflicts with other active gateways.
- First pl release.

Splitit for Commerce 1.0.0-beta2
---------------------------------
Released on 03-11-2020
- Added workaround for if ObfuscateEmail plugin is active. Splitit can\'t handle escaped email addresses.

Released on 16-10-2020
- First beta release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8dcd2c1c9743c2c78b79e3e15e92037d',
      'native_key' => 'commerce_splitit',
      'filename' => 'modNamespace/0c2bf02a543eaff2ac05e440d2d7f08a.vehicle',
      'namespace' => 'commerce_splitit',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e94d178f8b9b1f52fa601e9b87287af9',
      'native_key' => 'e94d178f8b9b1f52fa601e9b87287af9',
      'filename' => 'xPDOFileVehicle/862096f988cc436a31b5192e5cadbb2f.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4be54347fb702ff2bf24b8e6b6d34193',
      'native_key' => 'commerce_splitit.first_installment_percentage',
      'filename' => 'modSystemSetting/b31954067a0d9aca641dddb15aff2499.vehicle',
      'namespace' => 'commerce_splitit',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ac70ddd2c56eb4c319b9998de7b0946',
      'native_key' => 'commerce_splitit.num_of_installments',
      'filename' => 'modSystemSetting/f6feb6d8dde1f6591aaee25a7b82a1e2.vehicle',
      'namespace' => 'commerce_splitit',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd24d491680ba7bc45ec2ac35cf48513a',
      'native_key' => 'commerce_splitit.num_of_installments_default',
      'filename' => 'modSystemSetting/b2c2ab6938e98e6db22847035a0ab23c.vehicle',
      'namespace' => 'commerce_splitit',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '262adf3a62650d3b939b064b38976682',
      'native_key' => 'commerce_splitit.locale',
      'filename' => 'modSystemSetting/800e768b0cddda523ea7c86619d17816.vehicle',
      'namespace' => 'commerce_splitit',
    ),
  ),
);